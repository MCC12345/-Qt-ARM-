#include "widget.h"
#include "ui_widget.h"
#include <QDataStream>
#include <QString>
#include <QtCore>
#include <algorithm>
#include "QDebug"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    QSqlDatabase db1 =QSqlDatabase::addDatabase("QSQLITE");
            db1.setDatabaseName("../shujuku/test.db");
            bool res1 = db1.open();
            qDebug() << res1;




    server = new QTcpServer(this);//建立服务器对象基于当前界面
    //监听状态，监听所有可能连接的客户端
    //端口号一般设置1000以上，不要选择80开头
    if(!server->listen(QHostAddress::Any,5555))
    {
        //提示监听失败-
        qDebug() << "监听失败";
    }
    //建立一个信号与槽函数的连接机制
    //如果有客户端连接，服务器就会产生newConnection
    //则获取客户端的套接字，之后用于通信
    connect(server,&QTcpServer::newConnection,this,&Widget::getSocket);


}

Widget::~Widget()
{
    delete ui;
}

void Widget::getSocket()
{
    //获取客户端连接后的套字节信息
    socket = server->nextPendingConnection();
    //如果有数据发送过来，套接字对象会产生一个准备读取信号，
    //则通过界面对象，执行槽函数接收数据
    connect(socket,&QTcpSocket::readyRead,this,&Widget::getMsg);
}

void Widget::getMsg()
{


     bufSize=0;
    //数据流方式
    //套接字对象与数据流对象关联
    QDataStream in(socket);//用于接收数据的对象
    in.setVersion(QDataStream::Qt_4_7);

    if(bufSize == 0)
    {
        if(socket->bytesAvailable()<2)
        {
            qDebug() << "数据大小值没有接收到";
            return;//终止当前函数
        }
       in >> bufSize;//bufSize只有2个字节大小 放入2值（2个字节）
       if(socket->bytesAvailable()<bufSize)
       {
           //判断真实数据与大小值进行比较
           qDebug() << "数据真实值没有接收到";
           return;
       }
       in >> msg;//数据流中获取数据，存放到msg

       //登录界面信息
       if(msg == "111")
       {

        in >> deng_lu_zhanghao >> deng_lu_mima; // 读取其他数据
        ui->lineEdit->setText(deng_lu_zhanghao);
        ui->lineEdit_2->setText(deng_lu_mima);
        qDebug() << 8888;
        //连接好数据库后，查询语句，将查询结果放到Qt程序中显示
        QSqlQuery query;
       query.exec("select * from jiating");
        while(query.next())
        {
                username = query.value("username").toString();
                password = query.value("password").toString();

                qDebug() << username << password;

                if(deng_lu_zhanghao == username and deng_lu_mima == password)
                {
                    Deng_lu_Writedata1();//登录成功发送函数
                }

        }
       }
       //注册界面信息
       else if(msg == "222")
       {
           in >> zhu_ce_zhanghao >>zhu_ce_mima; // 读取其他数据
           ui->lineEdit_3->setText(zhu_ce_zhanghao);
           ui->lineEdit_4->setText(zhu_ce_mima);


           //获取系统中id值最大是多少
           QString userid;
           QSqlQuery query;
           query.exec("SELECT MAX(IDname) FROM jiating;");
           if(query.next())
           {
                   userid = query.value(0).toString();
           }
           qDebug() << userid;


           //向houseDB表中增加新用户信息
           //userid.toInt()+1
           QSqlQuery query1;
           query1.prepare("insert into jiating(IDname,username,password) VALUES(:id,:name,:pwd)");
           query1.bindValue(":id",userid.toInt()+1);
           query1.bindValue(":name",zhu_ce_zhanghao);
           query1.bindValue(":pwd",zhu_ce_mima);
           query1.exec();

       }
       //LED按钮1发出的三个灯状态
       else if(msg == "333")
       {
           in >> LED1 >> LED2 >> LED3; // 读取其他数据
           ui->lineEdit_5->setText(LED1);
           ui->lineEdit_6->setText(LED2);
           ui->lineEdit_7->setText(LED3);
           //获取系统中id值最大是多少
           QString userid;
           QSqlQuery query;
           query.exec("SELECT MAX(IDname) FROM LEDzhuangtai;");
           if(query.next())
           {
                   userid = query.value(0).toString();
           }
           qDebug() << userid;


           //向LED表中增加新信息
           //userid.toInt()+1
           QSqlQuery query1;
           query1.prepare("insert into LEDzhuangtai(IDname,LEDred,LEDgled,LEDblue) VALUES(:id,:ledred,:ledgled,:ledblue)");
           query1.bindValue(":id",userid.toInt()+1);
           query1.bindValue(":ledred",LED1);
           query1.bindValue(":ledgled",LED2);
           query1.bindValue(":ledblue",LED3);
           query1.exec();
       }
       //LED按钮2发出的三个灯状态
       else if(msg == "444")
       {
           in >> LED1 >> LED2 >> LED3; // 读取其他数据
           ui->lineEdit_5->setText(LED1);
           ui->lineEdit_6->setText(LED2);
           ui->lineEdit_7->setText(LED3);

           //获取系统中id值最大是多少
           QString userid;
           QSqlQuery query;
           query.exec("SELECT MAX(IDname) FROM LEDzhuangtai;");
           if(query.next())
           {
                   userid = query.value(0).toString();
           }
           qDebug() << userid;


           //向LED表中增加新信息
           //userid.toInt()+1
           QSqlQuery query1;
           query1.prepare("insert into LEDzhuangtai(IDname,LEDred,LEDgled,LEDblue) VALUES(:id,:ledred,:ledgled,:ledblue)");
           query1.bindValue(":id",userid.toInt()+1);
           query1.bindValue(":ledred",LED1);
           query1.bindValue(":ledgled",LED2);
           query1.bindValue(":ledblue",LED3);
           query1.exec();
       }
       //LED按钮3发出的三个灯状态
       else if(msg == "555")
       {
           in >> LED1 >> LED2 >> LED3; // 读取其他数据
           ui->lineEdit_5->setText(LED1);
           ui->lineEdit_6->setText(LED2);
           ui->lineEdit_7->setText(LED3);

           //获取系统中id值最大是多少
           QString userid;
           QSqlQuery query;
           query.exec("SELECT MAX(IDname) FROM LEDzhuangtai;");
           if(query.next())
           {
                   userid = query.value(0).toString();
           }
           qDebug() << userid;


           //向LED表中增加新信息
           //userid.toInt()+1
           QSqlQuery query1;
           query1.prepare("insert into LEDzhuangtai(IDname,LEDred,LEDgled,LEDblue) VALUES(:id,:ledred,:ledgled,:ledblue)");
           query1.bindValue(":id",userid.toInt()+1);
           query1.bindValue(":ledred",LED1);
           query1.bindValue(":ledgled",LED2);
           query1.bindValue(":ledblue",LED3);
           query1.exec();
       }
       //温度和湿度的值
       else if(msg == "666")
       {
           in >> wenStr >> shiStr; // 读取其他数据
           ui->lineEdit_8->setText(wenStr);
           ui->lineEdit_9->setText(shiStr);

           //获取系统中id值最大是多少
           QString userid;
           QSqlQuery query;
           query.exec("SELECT MAX(IDname) FROM Wenshidu;");
           if(query.next())
           {
                   userid = query.value(0).toString();
           }
           qDebug() << userid;


           //向温湿度表中增加新信息
           //userid.toInt()+1
           QSqlQuery query1;
           query1.prepare("insert into Wenshidu(IDname,Wen,Shi) VALUES(:id,:wen,:shi)");
           query1.bindValue(":id",userid.toInt()+1);
           query1.bindValue(":wen",wenStr);
           query1.bindValue(":shi",shiStr);
           query1.exec();

       }
       //判断用户名是否存在
       else if(msg == "777")
       {
           in  >> arg1;
           qDebug() << arg1;
           //ui->lineEdit_3->setText(arg1);
           //用户名自检
           QSqlQuery query;
           query.prepare("select * from jiating where username = :name");
           query.bindValue(":name",arg1);
           query.exec();
           if(query.next())
           {
               Chong_ming_Writedata1();
           }
           else
           {
               Chong_ming_Writedata0();
           }

       }

    }


}

//登录成功发送函数
void Widget::Deng_lu_Writedata1()
{
    QString Type = "d_l_cheng_gong";
    QByteArray buf;//Qt字节数组，临时存储要发送的数据
    QDataStream out(&buf,QIODevice::WriteOnly);//数据对象
    out.setVersion(QDataStream::Qt_4_7);
    out << (quint16)0;//用两位表示数据的大小
    out << Type;
    out.device()->seek(0);//跳转到起始位置
    out << (quint16)(buf.size() - sizeof (quint16));
    socket->write(buf);// 使用套接字发送数据
}

void Widget::Chong_ming_Writedata1()
{
    QString Type = "yi_cun_zai";
    QByteArray buf;//Qt字节数组，临时存储要发送的数据
    QDataStream out(&buf,QIODevice::WriteOnly);//数据对象
    out.setVersion(QDataStream::Qt_4_7);
    out << (quint16)0;//用两位表示数据的大小
    out << Type;
    out.device()->seek(0);//跳转到起始位置
    out << (quint16)(buf.size() - sizeof (quint16));
    socket->write(buf);// 使用套接字发送数据
}
void Widget::Chong_ming_Writedata0()
{
    QString Type = "bu_cun_zai";
    QByteArray buf;//Qt字节数组，临时存储要发送的数据
    QDataStream out(&buf,QIODevice::WriteOnly);//数据对象
    out.setVersion(QDataStream::Qt_4_7);
    out << (quint16)0;//用两位表示数据的大小
    out << Type;
    out.device()->seek(0);//跳转到起始位置
    out << (quint16)(buf.size() - sizeof (quint16));
    socket->write(buf);// 使用套接字发送数据
}

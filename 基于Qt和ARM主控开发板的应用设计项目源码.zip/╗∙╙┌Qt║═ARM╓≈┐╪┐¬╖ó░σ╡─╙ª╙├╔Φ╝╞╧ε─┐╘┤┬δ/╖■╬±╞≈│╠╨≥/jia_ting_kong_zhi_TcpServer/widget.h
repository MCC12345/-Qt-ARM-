#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QSqlQuery>
namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void getSocket();
    void getMsg();
    void Deng_lu_Writedata1();
    void Chong_ming_Writedata1();
    void Chong_ming_Writedata0();
private:
    Ui::Widget *ui;
    QTcpServer *server;
    QTcpSocket *socket;
    quint16 bufSize;//存储数据大小值
    QString msg;//
    QString data;
    QString weifanzhuan__msg;
    QString deng_lu_zhanghao;
    QString deng_lu_mima;
    QString zhu_ce_zhanghao;
    QString zhu_ce_mima;
    QString LED1;
    QString LED2;
    QString LED3;
    QString wenStr;
    QString shiStr;
    QString username;
    QString password;
    QString arg1;//检查是否注册用户已存在

};

#endif // WIDGET_H

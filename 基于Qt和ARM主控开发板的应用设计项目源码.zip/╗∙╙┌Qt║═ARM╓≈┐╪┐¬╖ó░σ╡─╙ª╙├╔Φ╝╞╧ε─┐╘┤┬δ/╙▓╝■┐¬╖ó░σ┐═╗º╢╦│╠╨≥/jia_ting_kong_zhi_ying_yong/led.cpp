#include "led.h"
#include "ui_led.h"
#include "zhu_jie_mian.h"

extern "C"
{
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define RLED_DEV_PATH "/sys/class/leds/red/brightness"
#define GLED_DEV_PATH "/sys/class/leds/green/brightness"
#define BLED_DEV_PATH "/sys/class/leds/blue/brightness"
int flag1 = 1;
void readLED(void){
       int r_fd;

       r_fd = open(RLED_DEV_PATH,O_WRONLY);
       if(r_fd < 0)
       {
          perror(RLED_DEV_PATH);
          exit(1);
       }
     if(flag1==1){

           write(r_fd,"255",3);//点亮红灯
           flag1=0;
          }
     else{

             write(r_fd,"0",3);//熄灭红灯
             flag1=1;
           }


         close(r_fd);//关闭设备

}
}
int flag2 = 1;
void GLEDLED(void)
{


    int g_fd;
    g_fd = open(GLED_DEV_PATH,O_WRONLY);
    if(g_fd < 0)
    {
       perror(GLED_DEV_PATH);
       exit(1);
    }
  if(flag2==1){

        write(g_fd,"255",3);//点亮红灯
        flag2=0;
       }
  else{

          write(g_fd,"0",3);//熄灭红灯
          flag2=1;
        }


      close(g_fd);//关闭设备
}
int flag3 = 1;
void BLEDLED(void)
{
    int b_fd;

    b_fd = open(BLED_DEV_PATH,O_WRONLY);
    if(b_fd < 0)
    {
       perror(BLED_DEV_PATH);
       exit(1);
    }
  if(flag3==1){

        write(b_fd,"255",3);//点亮红灯
        flag3=0;
       }
  else{

          write(b_fd,"0",3);//熄灭红灯
          flag3=1;
        }


      close(b_fd);//关闭设备
}

LED::LED(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LED)
{
    ui->setupUi(this);
}

LED::~LED()
{
    delete ui;
}

void LED::on_pushButton_4_clicked()
{
    this->close();//关闭LED应用界面
    zhu_jie_mian *z = new zhu_jie_mian;//创建主界面对象
    z->show();//显示主界面
}



void LED::on_pushButton_clicked()
{
    readLED();
    led1 = QString::number(flag1);
    led2 = QString::number(flag2);
    led3 = QString::number(flag3);
    //发送三个LED状态信息
     QString Type = "333";
     QString ip = "192.168.153.244";
     QString port = "5555";
     //客户端连接服务器
     ClientSocket->connectToHost(ip,port.toInt());
     //第一次发送 发送标识符
     //设置数据缓冲区（缓存区：数据临时存放位置，其中数据还要不断进行更新）
     QByteArray buf;//Qt字节数组，临时存储要发送的数据
     QDataStream out(&buf,QIODevice::WriteOnly);//数据对象
     out.setVersion(QDataStream::Qt_4_7);//设置数据流版本
     out << (quint16)0;//用两位表示数据的大小
     out << Type;
     out << led1;
     out << led2;
     out << led3;
     out.device()->seek(0);//跳转到起始位置
     out << (quint16)(buf.size() - sizeof (quint16));
     ClientSocket->write(buf);
}

void LED::on_pushButton_2_clicked()
{
    GLEDLED();
    led1 = QString::number(flag1);
    led2 = QString::number(flag2);
    led3 = QString::number(flag3);
    //发送三个LED状态信息
     QString Type = "444";
     QString ip = "192.168.153.244";
     QString port = "5555";
     //客户端连接服务器
     ClientSocket->connectToHost(ip,port.toInt());
     //第一次发送 发送标识符
     //设置数据缓冲区（缓存区：数据临时存放位置，其中数据还要不断进行更新）
     QByteArray buf;//Qt字节数组，临时存储要发送的数据
     QDataStream out(&buf,QIODevice::WriteOnly);//数据对象
     out.setVersion(QDataStream::Qt_4_7);//设置数据流版本
     out << (quint16)0;//用两位表示数据的大小
     out << Type;
     out << led1;
     out << led2;
     out << led3;
     out.device()->seek(0);//跳转到起始位置
     out << (quint16)(buf.size() - sizeof (quint16));
     ClientSocket->write(buf);

}

void LED::on_pushButton_3_clicked()
{
    BLEDLED();
    led1 = QString::number(flag1);
    led2 = QString::number(flag2);
    led3 = QString::number(flag3);
    //发送三个LED状态信息
     QString Type = "555";
     QString ip = "192.168.153.244";
     QString port = "5555";
     //客户端连接服务器
     ClientSocket->connectToHost(ip,port.toInt());
     //第一次发送 发送标识符
     //设置数据缓冲区（缓存区：数据临时存放位置，其中数据还要不断进行更新）
     QByteArray buf;//Qt字节数组，临时存储要发送的数据
     QDataStream out(&buf,QIODevice::WriteOnly);//数据对象
     out.setVersion(QDataStream::Qt_4_7);//设置数据流版本
     out << (quint16)0;//用两位表示数据的大小
     out << Type;
     out << led1;
     out << led2;
     out << led3;
     out.device()->seek(0);//跳转到起始位置
     out << (quint16)(buf.size() - sizeof (quint16));
     ClientSocket->write(buf);
}

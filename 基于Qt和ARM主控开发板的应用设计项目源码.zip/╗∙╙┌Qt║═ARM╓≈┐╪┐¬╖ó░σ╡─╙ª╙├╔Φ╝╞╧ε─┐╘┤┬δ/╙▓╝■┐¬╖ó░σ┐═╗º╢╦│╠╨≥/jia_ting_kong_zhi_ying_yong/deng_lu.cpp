#include "deng_lu.h"
#include "ui_deng_lu.h"
#include <QVBoxLayout>
#include "QDebug"
#include <QLineEdit>
#include <QMessageBox>
QString Deng_lu_Type = "";//接收登录是否成功信息的全局变量
extern QString Deng_lu_Type;
deng_lu::deng_lu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::deng_lu)
{
    ui->setupUi(this);

    keyboard = new Keyboard();
    keyboard1 = new Keyboard();
    // 监听鼠标点击事件
    ui->lineEdit->installEventFilter(this);
    ui->lineEdit_2->installEventFilter(this);
    //文本框lineEdit信号与槽的连接
    connect(keyboard,SIGNAL(keyValue(int,QString)),this,SLOT(showText(int,QString)));
    //文本框lineEdit_2信号与槽的连接
    connect(keyboard1,SIGNAL(keyValue(int,QString)),this,SLOT(showText1(int,QString)));
    // 连接接收数据的槽函数
    connect(ClientSocket, &QTcpSocket::readyRead, this, &deng_lu::getMsg);
}

deng_lu::~deng_lu()
{
    delete ui;
}
bool deng_lu::eventFilter(QObject *watched, QEvent *event)
{
    //lineEdit过滤器
    //判断控制
    if(watched == ui->lineEdit)
    {
        //判断事件
        if(event->type() == QEvent::MouseButtonPress)
        {
            //打开软键盘界面,关闭其他软键盘界面
            keyboard->show();
            keyboard1->close();
            // 将输入焦点设置到输入框
            //textInput->setFocus();
        }
    }

    //lineEdit_2过滤器
    else if(watched == ui->lineEdit_2)
    {
        //判断事件
        if(event->type() == QEvent::MouseButtonPress)
        {
            //打开软键盘界面，关闭其他软键盘界面
            keyboard->close();
            keyboard1->show();

        }
    }
    //最后将事件交给上层对话框
    return QWidget::eventFilter(watched,event);
}
//文本框lineEdit槽函数
void deng_lu::showText(int key, QString value)
{
    //识别退格键
    if(key == Qt::Key_Backspace)
    {
        text.chop(1);
    }
    else
    {
        //value值（字符串）拼接操作
        text.append(value);
    }
    ui->lineEdit->setText(text);
    //qDebug() << text <<111;
}
//文本框lineEdit_2槽函数
void deng_lu::showText1(int key, QString value)
{
    //识别退格键
    if(key == Qt::Key_Backspace)
    {
        text1.chop(1);
    }
    else
    {
        //value值（字符串）拼接操作
        text1.append(value);
    }
    ui->lineEdit_2->setText(text1);

}

void deng_lu::on_pushButton_2_clicked()
{
    //注册按钮，跳转到注册界面
    zhu_ce *c = new zhu_ce;
    c->show();
    this->close();
}
//    登录按钮，跳转到主应用界面
void deng_lu::on_pushButton_clicked()
{
    //发送登录账号密码
    QString Type = "111";
    QString ip = "192.168.153.244";
    QString port = "5555";
    //客户端连接服务器
    ClientSocket->connectToHost(ip,port.toInt());
    //第一次发送 发送标识符
    //设置数据缓冲区（缓存区：数据临时存放位置，其中数据还要不断进行更新）
    QByteArray buf;//Qt字节数组，临时存储要发送的数据
    QDataStream out(&buf,QIODevice::WriteOnly);//数据对象
    out.setVersion(QDataStream::Qt_4_7);//设置数据流版本
    out << (quint16)0;//用两位表示数据的大小
    out << Type;
    out << ui->lineEdit->text();
    out << ui->lineEdit_2->text();
    out.device()->seek(0);//跳转到起始位置
    out << (quint16)(buf.size() - sizeof (quint16));
    ClientSocket->write(buf);



}

//接收登录是否成功的数据
void deng_lu::getMsg()
{

    bufSize=0;
   //数据流方式
   //套接字对象与数据流对象关联
   QDataStream in(ClientSocket);//用于接收数据的对象
   in.setVersion(QDataStream::Qt_4_7);

   if(bufSize == 0)
   {
       if(ClientSocket->bytesAvailable()<2)
       {
           qDebug() << "数据大小值没有接收到";
           return;//终止当前函数
       }
      in >> bufSize;//bufSize只有2个字节大小 放入2值（2个字节）
      if(ClientSocket->bytesAvailable()<bufSize)
      {
          //判断真实数据与大小值进行比较
          qDebug() << "数据真实值没有接收到";
          return;
      }
      in >> msg;//数据流中获取数据，存放到msg中
      qDebug() << msg <<666;
      Deng_lu_Type = msg; //将登录信息传给全局变量
   }
   //如果接收到了对比成功的字符串信息就登录跳转界面否则提示登录失败
   if(Deng_lu_Type == "d_l_cheng_gong")
   {
       zhu_jie_mian *z = new zhu_jie_mian;
       z->show();
       this->close();
   }
   else
   {
     qDebug() << "用户密码不匹配";
   }
}
//关闭虚拟键盘按钮
void deng_lu::on_pushButton_3_clicked()
{
   keyboard->close();
   keyboard1->close();

}

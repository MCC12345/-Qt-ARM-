#include "duo_mei_ti.h"
#include "ui_duo_mei_ti.h"
#include "zhu_jie_mian.h"
#include <QMediaPlayer>
#include <QFileDialog>
#include "QDebug"
#include <QMediaPlaylist>
#include <QUrl>
Duo_mei_ti::Duo_mei_ti(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Duo_mei_ti)
{

    ui->setupUi(this);
    //播放一个音频文件mp3
    //QMediaplayer属于音频播放对象
    player = new QMediaPlayer(this);
    //设置播放音量
    player->setVolume(50);//音频文件播放的初始音量值
    //开始播放音频文件
    music = new QMediaPlayer(this);
}


Duo_mei_ti::~Duo_mei_ti()
{
    delete ui;
}

void Duo_mei_ti::on_pushButton_7_clicked()
{
    this->close();//关闭当前应用界面
    zhu_jie_mian *z = new zhu_jie_mian;//创建主界面对象
    z->show();//显示主界面
}

//开始暂停按钮
void Duo_mei_ti::on_pushButton_clicked()
{
    if(ui->pushButton->text() == "开始")
    {
    music->play();;//开始
    ui->pushButton->setText("暂停");
    }
    else
    {
     music->pause();//暂停播放
     ui->pushButton->setText("开始");
    }

}
//结束播放按钮
void Duo_mei_ti::on_pushButton_2_clicked()
{
    music->stop();//停止
}
//打开一个窗口选择多个音频文件，按照特定的播放模式进行播放
void Duo_mei_ti::on_pushButton_3_clicked()
{
    //QMediaPlayer 对应播放一个音频文件
    //QMediaPlayList 对应播放多个音频文件
    //参数1：代表窗口基于哪个界面产生
    //参数2：标题的名称
    //参数3：默认打开位置
    //参数4：打开文件夹默认识别类型
    QStringList files = QFileDialog::getOpenFileNames(
                              this,
                              "打开音频文件夹",
                              "/home/mcc",
                              "音频文件 (*.mp3)");
    qDebug() << files;
    //向listwidget中添加歌名
    for (int i = 0; i < files.size(); ++i)
    {
        QString str = files[i];
        QListWidgetItem *item = new QListWidgetItem(str);
        ui->listWidget->addItem(item);

    }


    //初始化一个播放列表
    playlist = new QMediaPlaylist(this);
    //添加音频资源的路径（添加一个或多个）
    //如果需要从files中提取每一个音频文件的路径
    //每次根据歌曲数目自动添加到音频源中
   for (int i = 0; i < files.size(); ++i)
   {
       QUrl url = QUrl::fromLocalFile(files[i]);
       playlist->addMedia(QUrl(url));
       qDebug() << url << 111;
   }
    //设置播放模式
   playlist->setPlaybackMode(QMediaPlaylist::Loop);
   //播放列表对象自己不能单独进行音频播放
   //负责将多个音频文件进行结构的组合
   //QMediaPlayer *music = new QMediaPlayer(this);
   music->setPlaylist(playlist);//设置播放列表到播放源对象中


}

void Duo_mei_ti::on_pushButton_4_clicked()
{
     playlist->previous(); // 播放上一首
}

void Duo_mei_ti::on_pushButton_5_clicked()
{
    playlist->next(); // 播放下一首
}

#ifndef ZHU_CE_H
#define ZHU_CE_H

#include <QWidget>
#include "Keyboard.h"
#include "AbstractKeyboard.h"
#include <QLineEdit>
#include "deng_lu.h"
#include  <QTcpSocket>
#include <QSqlQuery>
using namespace AeaQt;

namespace Ui {
class zhu_ce;
}

class zhu_ce : public QWidget
{
    Q_OBJECT

public:
    explicit zhu_ce(QWidget *parent = nullptr);
    ~zhu_ce();

protected:
    //设置事件过滤器的声明
    bool eventFilter(QObject *watched, QEvent *event);


private slots:
    void showText(int key, QString value);
    void showText1(int key, QString value);
    void showText2(int key, QString value);
    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_clicked();

    void on_lineEdit_textChanged(const QString &arg1);
    void getMsg();
private:
    Ui::zhu_ce *ui;
    Keyboard *keyboard;
    Keyboard *keyboard1;
    Keyboard *keyboard2;
    QString text;//用于拼接字符串的变量
    QString text1;
    QString text2;
    QTcpSocket *ClientSocket  = new QTcpSocket;
    quint16 bufSize;//存储数据大小值
    QString msg;
};

#endif // ZHU_CE_H

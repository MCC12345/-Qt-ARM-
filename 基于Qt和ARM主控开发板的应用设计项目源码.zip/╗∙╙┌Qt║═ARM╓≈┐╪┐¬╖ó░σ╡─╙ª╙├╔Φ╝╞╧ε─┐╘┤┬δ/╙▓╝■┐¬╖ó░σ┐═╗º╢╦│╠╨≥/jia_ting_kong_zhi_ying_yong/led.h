#ifndef LED_H
#define LED_H

#include <QWidget>
#include <QTcpSocket>
namespace Ui {
class LED;
}

class LED : public QWidget
{
    Q_OBJECT

public:
    explicit LED(QWidget *parent = nullptr);
    ~LED();

private slots:
    void on_pushButton_4_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::LED *ui;
    QTcpSocket *ClientSocket  = new QTcpSocket;
    QString led1;
    QString led2;
    QString led3;
};

#endif // LED_H

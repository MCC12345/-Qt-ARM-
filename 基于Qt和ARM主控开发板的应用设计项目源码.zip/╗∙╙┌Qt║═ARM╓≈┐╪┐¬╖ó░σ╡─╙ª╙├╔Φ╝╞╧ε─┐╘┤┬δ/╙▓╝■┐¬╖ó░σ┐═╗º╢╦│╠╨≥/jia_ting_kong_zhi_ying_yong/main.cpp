﻿#include <QApplication>
#include <QFontDatabase>
#include "deng_lu.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    deng_lu window;
    window.show();

    return a.exec();
}

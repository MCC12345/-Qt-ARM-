#ifndef DENG_LU_H
#define DENG_LU_H

#include <QWidget>
#include "Keyboard.h"
#include "AbstractKeyboard.h"
#include <QLineEdit>
#include "zhu_ce.h"
#include "zhu_jie_mian.h"
#include <QTcpSocket>
#include <QMessageBox>
using namespace AeaQt;

namespace Ui{
class deng_lu;
}

class deng_lu : public QWidget
{
    Q_OBJECT

public:
    explicit deng_lu(QWidget *parent = nullptr);
    ~deng_lu();

protected:
    //设置事件过滤器的声明
    bool eventFilter(QObject *watched, QEvent *event);

private slots:
    void showText(int key, QString value);
    void showText1(int key, QString value);
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

    void on_pushButton_3_clicked();

    void getMsg();
private:
    Ui::deng_lu *ui;
    Keyboard *keyboard;
    Keyboard *keyboard1;
    QString text;//用于拼接字符串的变量
    QString text1;
    QTcpSocket *ClientSocket  = new QTcpSocket;
    //接收数据变量
    quint16 bufSize;//存储数据大小值
    QString msg;
};

#endif // DENG_LU_H

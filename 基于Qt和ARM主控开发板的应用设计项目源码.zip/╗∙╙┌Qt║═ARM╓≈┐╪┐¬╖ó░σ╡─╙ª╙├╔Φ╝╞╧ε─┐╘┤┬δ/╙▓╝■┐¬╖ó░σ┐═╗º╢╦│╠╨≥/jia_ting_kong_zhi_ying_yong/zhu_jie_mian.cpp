#include "zhu_jie_mian.h"
#include "ui_zhu_jie_mian.h"
#include "deng_lu.h"
zhu_jie_mian::zhu_jie_mian(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::zhu_jie_mian)
{
    ui->setupUi(this);
}

zhu_jie_mian::~zhu_jie_mian()
{
    delete ui;
}

void zhu_jie_mian::on_toolButton_clicked()
{
    //LED应用按钮，跳转到LED应用界面
    LED *l = new LED;
    l->show();
    this->close();
}

void zhu_jie_mian::on_toolButton_3_clicked()
{
    //多媒体应用按钮，跳转到多媒体应用界面
    Duo_mei_ti *d = new Duo_mei_ti;
    d->show();
    this->close();
}

void zhu_jie_mian::on_toolButton_2_clicked()
{
    //温湿度应用按钮，跳转到温湿度应用界面
    Wen_shi_du *w = new Wen_shi_du;
    w->show();
    this->close();

}

void zhu_jie_mian::on_toolButton_4_clicked()
{
    //返回主界面按钮
    deng_lu *d = new deng_lu;
    d->show();
    this->close();
}

#ifndef DUO_MEI_TI_H
#define DUO_MEI_TI_H

#include <QWidget>
#include <QMediaPlayer>

namespace Ui {
class Duo_mei_ti;
}

class Duo_mei_ti : public QWidget
{
    Q_OBJECT

public:
    explicit Duo_mei_ti(QWidget *parent = nullptr);
    ~Duo_mei_ti();

private slots:
    void on_pushButton_7_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

private:
    Ui::Duo_mei_ti *ui;
    QMediaPlayer *player;
    QMediaPlayer *music;
    QMediaPlaylist *playlist;
};

#endif // DUO_MEI_TI_H

#ifndef WEN_SHI_DU_H
#define WEN_SHI_DU_H

#include <QWidget>
#include <QTimer>
#include <QTcpSocket>
namespace Ui {
class Wen_shi_du;
}

class Wen_shi_du : public QWidget
{
    Q_OBJECT

public:
    explicit Wen_shi_du(QWidget *parent = nullptr);
    ~Wen_shi_du();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();
    void getData();

private:
    Ui::Wen_shi_du *ui;
    QTimer *timer;
    QTcpSocket *ClientSocket  = new QTcpSocket;
};

#endif // WEN_SHI_DU_H

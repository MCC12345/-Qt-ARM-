#ifndef ZHU_JIE_MIAN_H
#define ZHU_JIE_MIAN_H

#include <QWidget>
#include "led.h"
#include "wen_shi_du.h"
#include "duo_mei_ti.h"


namespace Ui {
class zhu_jie_mian;
}

class zhu_jie_mian : public QWidget
{
    Q_OBJECT

public:
    explicit zhu_jie_mian(QWidget *parent = nullptr);
    ~zhu_jie_mian();

private slots:
    void on_toolButton_clicked();

    void on_toolButton_3_clicked();

    void on_toolButton_2_clicked();

    void on_toolButton_4_clicked();

private:
    Ui::zhu_jie_mian *ui;
};

#endif // ZHU_JIE_MIAN_H

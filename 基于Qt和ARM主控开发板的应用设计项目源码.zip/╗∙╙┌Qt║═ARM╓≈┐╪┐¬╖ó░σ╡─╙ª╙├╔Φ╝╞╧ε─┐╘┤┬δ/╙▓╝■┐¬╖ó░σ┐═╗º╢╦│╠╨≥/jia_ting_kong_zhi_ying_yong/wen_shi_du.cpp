#include "wen_shi_du.h"
#include "ui_wen_shi_du.h"
#include "zhu_jie_mian.h"

unsigned char buf[4];
extern "C"
{
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h> // 添加错误处理头文件

void getTempHumi() {
    int fd;

    int length;
    fd = open("/dev/dht11", O_RDONLY);

    if (fd == -1)
    {
        perror("Error opening /dev/dht11"); // 添加错误处理

    }

        length = read(fd, buf, 6);
        if (length == -1)
        {
            perror("Error reading /dev/dht11"); // 添加错误处理
        }


    close(fd);

}
}

Wen_shi_du::Wen_shi_du(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Wen_shi_du)
{
    ui->setupUi(this);
    timer = new QTimer(this);

    connect(timer,&QTimer::timeout,this,&Wen_shi_du::getData);
}

Wen_shi_du::~Wen_shi_du()
{
    delete ui;
}

void Wen_shi_du::on_pushButton_2_clicked()
{
    this->close();//关闭当前应用界面
    zhu_jie_mian *z = new zhu_jie_mian;//创建主界面对象
    z->show();//显示主界面
}
//采集数据按钮
void Wen_shi_du::on_pushButton_clicked()
{
    //1.通过C的功能，获取一次数据
    //2.通过定时器实现循环效果
    if(ui->pushButton->text() == "数据采集")
    {
       timer->start(2000);//单位ms
       ui->pushButton->setText("停止采集");

    }
    else
    {
        timer->stop();//定时器停止
        ui->pushButton->setText("数据采集");
    }
}
//采集温度槽函数
void Wen_shi_du::getData()
{
    getTempHumi();//采集一次数据
    //buf数组中 buf[2]--温度整数 buf[3]--温度小数
    //buf[0]-湿度整数 buf[1]-湿度小数
    //如何将char变为字符串
    unsigned char wen_1,wen_2,shi_1,shi_2;
    wen_1 = buf[2];
    wen_2 = buf[3];
    shi_1 = buf[0];
    shi_2 = buf[1];
    // 将 wen 和 shi 转换为 QString
    QString wenStr = QString::number(wen_1) + "." + QString::number(wen_2);
    QString shiStr = QString::number(shi_1) + "." + QString::number(shi_2);


    ui->lineEdit->setText(wenStr);//温度值
    ui->lineEdit_2->setText(shiStr);//湿度值
    //发送温度湿度值
     QString Type = "666";
     QString ip = "192.168.153.244";
     QString port = "5555";
     //客户端连接服务器
     ClientSocket->connectToHost(ip,port.toInt());
     //第一次发送 发送标识符
     //设置数据缓冲区（缓存区：数据临时存放位置，其中数据还要不断进行更新）
     QByteArray buf;//Qt字节数组，临时存储要发送的数据
     QDataStream out(&buf,QIODevice::WriteOnly);//数据对象
     out.setVersion(QDataStream::Qt_4_7);//设置数据流版本
     out << (quint16)0;//用两位表示数据的大小
     out << Type;
     out << wenStr;
     out << shiStr;
     out.device()->seek(0);//跳转到起始位置
     out << (quint16)(buf.size() - sizeof (quint16));
     ClientSocket->write(buf);
}

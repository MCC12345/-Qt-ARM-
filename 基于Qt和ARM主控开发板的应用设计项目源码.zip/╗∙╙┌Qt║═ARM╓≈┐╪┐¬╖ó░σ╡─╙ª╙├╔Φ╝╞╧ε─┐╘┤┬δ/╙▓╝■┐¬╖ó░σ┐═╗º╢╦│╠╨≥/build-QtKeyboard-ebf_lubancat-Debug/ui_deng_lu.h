/********************************************************************************
** Form generated from reading UI file 'deng_lu.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DENG_LU_H
#define UI_DENG_LU_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_deng_lu
{
public:
    QWidget *widget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLineEdit *lineEdit_2;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QLabel *label;
    QPushButton *pushButton_3;

    void setupUi(QWidget *deng_lu)
    {
        if (deng_lu->objectName().isEmpty())
            deng_lu->setObjectName(QStringLiteral("deng_lu"));
        deng_lu->resize(800, 480);
        deng_lu->setStyleSheet(QLatin1String("QWidget#widget{\n"
"background-image: url(:/img/neom-NPDnHmYsl6Y-unsplash (1).jpg);}"));
        widget = new QWidget(deng_lu);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 0, 800, 480));
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(310, 340, 93, 28));
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(470, 340, 93, 28));
        lineEdit_2 = new QLineEdit(widget);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(400, 250, 113, 21));
        lineEdit_2->setEchoMode(QLineEdit::Password);
        label_2 = new QLabel(widget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(320, 240, 51, 41));
        label_2->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 87 12pt \"Arial Black\";"));
        lineEdit = new QLineEdit(widget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(400, 190, 113, 21));
        label = new QLabel(widget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(320, 190, 61, 21));
        label->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 87 12pt \"Arial Black\";"));
        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(20, 0, 771, 41));
        pushButton_3->setStyleSheet(QStringLiteral(""));

        retranslateUi(deng_lu);

        QMetaObject::connectSlotsByName(deng_lu);
    } // setupUi

    void retranslateUi(QWidget *deng_lu)
    {
        deng_lu->setWindowTitle(QApplication::translate("deng_lu", "Form", nullptr));
        pushButton->setText(QApplication::translate("deng_lu", "\347\231\273\345\275\225", nullptr));
        pushButton_2->setText(QApplication::translate("deng_lu", "\346\263\250\345\206\214", nullptr));
        label_2->setText(QApplication::translate("deng_lu", "\345\257\206\347\240\201", nullptr));
        label->setText(QApplication::translate("deng_lu", "\350\264\246\345\217\267", nullptr));
        pushButton_3->setText(QApplication::translate("deng_lu", "\345\205\263\351\227\255\351\224\256\347\233\230", nullptr));
    } // retranslateUi

};

namespace Ui {
    class deng_lu: public Ui_deng_lu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DENG_LU_H

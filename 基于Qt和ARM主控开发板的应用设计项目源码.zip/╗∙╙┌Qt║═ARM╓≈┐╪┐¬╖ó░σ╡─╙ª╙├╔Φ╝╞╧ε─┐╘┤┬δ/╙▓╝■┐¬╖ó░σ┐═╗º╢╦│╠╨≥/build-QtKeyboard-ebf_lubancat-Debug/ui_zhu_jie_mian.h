/********************************************************************************
** Form generated from reading UI file 'zhu_jie_mian.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ZHU_JIE_MIAN_H
#define UI_ZHU_JIE_MIAN_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_zhu_jie_mian
{
public:
    QWidget *widget;
    QToolButton *toolButton_2;
    QToolButton *toolButton_3;
    QToolButton *toolButton;
    QToolButton *toolButton_4;

    void setupUi(QWidget *zhu_jie_mian)
    {
        if (zhu_jie_mian->objectName().isEmpty())
            zhu_jie_mian->setObjectName(QStringLiteral("zhu_jie_mian"));
        zhu_jie_mian->resize(800, 450);
        zhu_jie_mian->setStyleSheet(QLatin1String("QWidget#widget\n"
"{\n"
"background-image: url(:/img/chris-l-dGogbPrvA-unsplash.jpg);\n"
"}\n"
"QToolButton\n"
"{\n"
"	border-style:none;\n"
"}"));
        widget = new QWidget(zhu_jie_mian);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 0, 800, 450));
        toolButton_2 = new QToolButton(widget);
        toolButton_2->setObjectName(QStringLiteral("toolButton_2"));
        toolButton_2->setGeometry(QRect(480, 40, 87, 86));
        toolButton_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/img/Spotify.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton_2->setIcon(icon);
        toolButton_2->setIconSize(QSize(80, 80));
        toolButton_2->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        toolButton_3 = new QToolButton(widget);
        toolButton_3->setObjectName(QStringLiteral("toolButton_3"));
        toolButton_3->setGeometry(QRect(300, 40, 87, 86));
        toolButton_3->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/img/Music.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton_3->setIcon(icon1);
        toolButton_3->setIconSize(QSize(80, 80));
        toolButton_3->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        toolButton = new QToolButton(widget);
        toolButton->setObjectName(QStringLiteral("toolButton"));
        toolButton->setGeometry(QRect(110, 40, 87, 86));
        toolButton->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/img/Home Kit.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton->setIcon(icon2);
        toolButton->setIconSize(QSize(80, 80));
        toolButton->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        toolButton_4 = new QToolButton(widget);
        toolButton_4->setObjectName(QStringLiteral("toolButton_4"));
        toolButton_4->setGeometry(QRect(10, 10, 71, 51));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/img/return.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton_4->setIcon(icon3);
        toolButton_4->setIconSize(QSize(80, 80));

        retranslateUi(zhu_jie_mian);

        QMetaObject::connectSlotsByName(zhu_jie_mian);
    } // setupUi

    void retranslateUi(QWidget *zhu_jie_mian)
    {
        zhu_jie_mian->setWindowTitle(QApplication::translate("zhu_jie_mian", "Form", nullptr));
        toolButton_2->setText(QApplication::translate("zhu_jie_mian", "\346\270\251\346\271\277\345\272\246", nullptr));
        toolButton_3->setText(QApplication::translate("zhu_jie_mian", "\351\237\263\344\271\220", nullptr));
        toolButton->setText(QApplication::translate("zhu_jie_mian", "\345\256\266\347\224\265\346\216\247\345\210\266", nullptr));
        toolButton_4->setText(QApplication::translate("zhu_jie_mian", "...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class zhu_jie_mian: public Ui_zhu_jie_mian {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ZHU_JIE_MIAN_H

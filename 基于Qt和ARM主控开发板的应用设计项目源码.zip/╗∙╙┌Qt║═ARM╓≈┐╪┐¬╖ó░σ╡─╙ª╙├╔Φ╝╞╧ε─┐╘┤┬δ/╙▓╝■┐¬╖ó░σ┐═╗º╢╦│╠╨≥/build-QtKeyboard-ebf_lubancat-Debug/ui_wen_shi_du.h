/********************************************************************************
** Form generated from reading UI file 'wen_shi_du.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WEN_SHI_DU_H
#define UI_WEN_SHI_DU_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Wen_shi_du
{
public:
    QWidget *widget;
    QPushButton *pushButton_2;
    QLineEdit *lineEdit;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton;

    void setupUi(QWidget *Wen_shi_du)
    {
        if (Wen_shi_du->objectName().isEmpty())
            Wen_shi_du->setObjectName(QStringLiteral("Wen_shi_du"));
        Wen_shi_du->resize(800, 480);
        Wen_shi_du->setStyleSheet(QLatin1String("QWidget#widget{\n"
"background-image: url(:/img/jorge-ramirez-2bJ2OH9e9J8-unsplash.jpg);\n"
"}"));
        widget = new QWidget(Wen_shi_du);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 0, 800, 480));
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(690, 20, 71, 31));
        lineEdit = new QLineEdit(widget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(350, 130, 121, 41));
        label = new QLabel(widget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(290, 140, 61, 21));
        label->setStyleSheet(QLatin1String("color: rgb(0, 0, 127);\n"
"font: 87 12pt \"Arial Black\";"));
        label_2 = new QLabel(widget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(290, 220, 41, 16));
        label_2->setStyleSheet(QLatin1String("color: rgb(0, 0, 127);\n"
"font: 87 12pt \"Arial Black\";"));
        lineEdit_2 = new QLineEdit(widget);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(350, 210, 121, 41));
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(370, 290, 91, 61));

        retranslateUi(Wen_shi_du);

        QMetaObject::connectSlotsByName(Wen_shi_du);
    } // setupUi

    void retranslateUi(QWidget *Wen_shi_du)
    {
        Wen_shi_du->setWindowTitle(QApplication::translate("Wen_shi_du", "Form", nullptr));
        pushButton_2->setText(QApplication::translate("Wen_shi_du", "\350\277\224\345\233\236", nullptr));
        label->setText(QApplication::translate("Wen_shi_du", "\346\270\251\345\272\246", nullptr));
        label_2->setText(QApplication::translate("Wen_shi_du", "\346\271\277\345\272\246", nullptr));
        pushButton->setText(QApplication::translate("Wen_shi_du", "\346\225\260\346\215\256\351\207\207\351\233\206", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Wen_shi_du: public Ui_Wen_shi_du {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WEN_SHI_DU_H

/********************************************************************************
** Form generated from reading UI file 'led.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LED_H
#define UI_LED_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LED
{
public:
    QWidget *widget;
    QPushButton *pushButton_3;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QPushButton *pushButton_4;

    void setupUi(QWidget *LED)
    {
        if (LED->objectName().isEmpty())
            LED->setObjectName(QStringLiteral("LED"));
        LED->resize(800, 480);
        LED->setStyleSheet(QLatin1String("QWidget#widget{\n"
"background-image: url(:/img/20231020110352.jpg);\n"
"}"));
        widget = new QWidget(LED);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 0, 800, 480));
        widget->setStyleSheet(QStringLiteral(""));
        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(530, 90, 101, 41));
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(360, 90, 111, 41));
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(190, 90, 111, 41));
        pushButton_4 = new QPushButton(widget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(720, 10, 61, 31));

        retranslateUi(LED);

        QMetaObject::connectSlotsByName(LED);
    } // setupUi

    void retranslateUi(QWidget *LED)
    {
        LED->setWindowTitle(QApplication::translate("LED", "Form", nullptr));
        pushButton_3->setText(QApplication::translate("LED", "\345\256\266\347\224\2653", nullptr));
        pushButton_2->setText(QApplication::translate("LED", "\345\256\266\347\224\2652", nullptr));
        pushButton->setText(QApplication::translate("LED", "\345\256\266\347\224\2651", nullptr));
        pushButton_4->setText(QApplication::translate("LED", "\350\277\224\345\233\236", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LED: public Ui_LED {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LED_H

/********************************************************************************
** Form generated from reading UI file 'duo_mei_ti.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DUO_MEI_TI_H
#define UI_DUO_MEI_TI_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Duo_mei_ti
{
public:
    QWidget *widget;
    QListWidget *listWidget;
    QPushButton *pushButton_4;
    QPushButton *pushButton;
    QPushButton *pushButton_5;
    QPushButton *pushButton_7;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_6;

    void setupUi(QWidget *Duo_mei_ti)
    {
        if (Duo_mei_ti->objectName().isEmpty())
            Duo_mei_ti->setObjectName(QStringLiteral("Duo_mei_ti"));
        Duo_mei_ti->resize(800, 480);
        Duo_mei_ti->setStyleSheet(QLatin1String("QWidget#widget{\n"
"background-image: url(:/img/adrian-korte-5gn2soeAc40-unsplash.jpg);\n"
"}"));
        widget = new QWidget(Duo_mei_ti);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 0, 800, 480));
        listWidget = new QListWidget(widget);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        listWidget->setGeometry(QRect(350, 70, 301, 211));
        pushButton_4 = new QPushButton(widget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(330, 310, 93, 28));
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(470, 300, 81, 61));
        pushButton_5 = new QPushButton(widget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(580, 310, 93, 28));
        pushButton_7 = new QPushButton(widget);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(700, 20, 61, 31));
        layoutWidget = new QWidget(widget);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(170, 80, 121, 181));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_2 = new QPushButton(layoutWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        verticalLayout->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(layoutWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));

        verticalLayout->addWidget(pushButton_3);

        pushButton_6 = new QPushButton(layoutWidget);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));

        verticalLayout->addWidget(pushButton_6);


        retranslateUi(Duo_mei_ti);

        QMetaObject::connectSlotsByName(Duo_mei_ti);
    } // setupUi

    void retranslateUi(QWidget *Duo_mei_ti)
    {
        Duo_mei_ti->setWindowTitle(QApplication::translate("Duo_mei_ti", "Form", nullptr));
        pushButton_4->setText(QApplication::translate("Duo_mei_ti", "\344\270\212\344\270\200\346\233\262", nullptr));
        pushButton->setText(QApplication::translate("Duo_mei_ti", "\345\274\200\345\247\213", nullptr));
        pushButton_5->setText(QApplication::translate("Duo_mei_ti", "\344\270\213\344\270\200\346\233\262", nullptr));
        pushButton_7->setText(QApplication::translate("Duo_mei_ti", "\350\277\224\345\233\236", nullptr));
        pushButton_2->setText(QApplication::translate("Duo_mei_ti", "\347\273\223\346\235\237\346\222\255\346\224\276", nullptr));
        pushButton_3->setText(QApplication::translate("Duo_mei_ti", "\351\200\211\346\213\251\346\222\255\346\224\276\346\226\207\344\273\266", nullptr));
        pushButton_6->setText(QApplication::translate("Duo_mei_ti", "\351\241\272\345\272\217\346\222\255\346\224\276", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Duo_mei_ti: public Ui_Duo_mei_ti {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DUO_MEI_TI_H

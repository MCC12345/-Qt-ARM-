/********************************************************************************
** Form generated from reading UI file 'zhu_ce.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ZHU_CE_H
#define UI_ZHU_CE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_zhu_ce
{
public:
    QWidget *widget;
    QLabel *label;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;

    void setupUi(QWidget *zhu_ce)
    {
        if (zhu_ce->objectName().isEmpty())
            zhu_ce->setObjectName(QStringLiteral("zhu_ce"));
        zhu_ce->resize(800, 480);
        zhu_ce->setStyleSheet(QLatin1String("QWidget#widget{\n"
"background-image: url(:/img/neom-NPDnHmYsl6Y-unsplash (1).jpg);\n"
"}"));
        widget = new QWidget(zhu_ce);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 0, 800, 480));
        label = new QLabel(widget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(380, 180, 51, 20));
        label->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 87 12pt \"Arial Black\";"));
        lineEdit = new QLineEdit(widget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(450, 180, 113, 21));
        lineEdit_2 = new QLineEdit(widget);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(450, 230, 113, 21));
        label_2 = new QLabel(widget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(380, 230, 51, 21));
        label_2->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 87 12pt \"Arial Black\";"));
        label_3 = new QLabel(widget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(361, 280, 81, 20));
        label_3->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"font: 87 12pt \"Arial Black\";"));
        lineEdit_3 = new QLineEdit(widget);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(450, 280, 113, 21));
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(360, 340, 93, 28));
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(530, 340, 93, 28));
        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(10, 10, 781, 51));

        retranslateUi(zhu_ce);

        QMetaObject::connectSlotsByName(zhu_ce);
    } // setupUi

    void retranslateUi(QWidget *zhu_ce)
    {
        zhu_ce->setWindowTitle(QApplication::translate("zhu_ce", "Form", nullptr));
        label->setText(QApplication::translate("zhu_ce", "\350\264\246\345\217\267", nullptr));
        label_2->setText(QApplication::translate("zhu_ce", "\345\257\206\347\240\201", nullptr));
        label_3->setText(QApplication::translate("zhu_ce", "\347\241\256\350\256\244\345\257\206\347\240\201", nullptr));
        pushButton->setText(QApplication::translate("zhu_ce", "\346\263\250\345\206\214", nullptr));
        pushButton_2->setText(QApplication::translate("zhu_ce", "\350\277\224\345\233\236\347\231\273\345\275\225", nullptr));
        pushButton_3->setText(QApplication::translate("zhu_ce", "\345\205\263\351\227\255\351\224\256\347\233\230", nullptr));
    } // retranslateUi

};

namespace Ui {
    class zhu_ce: public Ui_zhu_ce {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ZHU_CE_H
